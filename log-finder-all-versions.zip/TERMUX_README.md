# Log Account Finder - Termux Version

## 🚀 การติดตั้งและใช้งานบน Termux

### ปัญหาที่แก้ไขสำหรับ Termux:
- ✅ แก้ไขปัญหา multiprocessing ที่ไม่ทำงานบน Termux
- ✅ ใช้ ThreadPoolExecutor แทน multiprocessing.Pool
- ✅ ปรับขนาด chunk และจำนวน workers ให้เหมาะกับ Termux
- ✅ เพิ่มการจัดการ error และ timeout
- ✅ สร้าง fallback สำหรับ mmap ที่อาจไม่ทำงาน
- ✅ ปรับ UI ให้เหมาะกับหน้าจอมือถือ

## 📦 การติดตั้ง

### วิธีที่ 1: ใช้ Setup Script (แนะนำ)
```bash
# ดาวน์โหลดไฟล์และรัน setup script
bash termux_setup.sh
```

### วิธีที่ 2: ติดตั้งด้วยตนเอง
```bash
# อัปเดต packages
pkg update && pkg upgrade

# ติดตั้ง Python
pkg install python python-pip

# ติดตั้ง dependencies
pip install flask flask-cors

# สร้างโฟลเดอร์
mkdir -p log result
```

## 🎯 การใช้งาน

### 1. เตรียมไฟล์ Log
วางไฟล์ .txt ที่มีข้อมูล log ในโฟลเดอร์ `log/`

รูปแบบข้อมูลที่รองรับ:
```
https://example.com:user@gmail.com:password123
http://site.com:admin@yahoo.com:secret789
other:data@hotmail.com:test123
```

### 2. วิธีการรัน

#### แบบ Command Line:
```bash
python termux_compatible_main.py
```

#### แบบ Web Interface (แนะนำ):
```bash
python termux_flask_app.py
```
จากนั้นเปิด http://localhost:5000 ในเบราว์เซอร์

## 🔧 การแก้ไขปัญหา

### ปัญหาที่อาจพบ:

#### 1. "No module named 'flask'"
```bash
pip install flask flask-cors
```

#### 2. "Permission denied"
```bash
chmod +x termux_compatible_main.py
chmod +x termux_flask_app.py
```

#### 3. "No .txt files found"
- ตรวจสอบว่ามีไฟล์ .txt ในโฟลเดอร์ `log/`
- ใช้ไฟล์ตัวอย่าง `log/sample.txt` สำหรับทดสอบ

#### 4. การค้นหาช้าหรือค้าง
- ลดขนาดไฟล์ log ที่ประมวลผลครั้งละไฟล์
- ปิดแอปอื่นๆ เพื่อเพิ่ม RAM ที่ว่าง
- ใช้ไฟล์ log ที่มีขนาดไม่เกิน 100MB ต่อไฟล์

#### 5. "Address already in use"
```bash
# หยุด process ที่ใช้ port 5000
pkill -f python
# หรือเปลี่ยน port ในโค้ด
```

## ⚡ การปรับแต่งประสิทธิภาพ

### สำหรับ Termux:
1. **จำกัดขนาดไฟล์**: ไฟล์ log ไม่ควรเกิน 100MB ต่อไฟล์
2. **ปิดแอปอื่น**: เพื่อเพิ่ม RAM ที่ใช้ได้
3. **ใช้ storage ภายใน**: หลีกเลี่ยงการใช้ SD card
4. **ปรับค่า workers**: ลดจำนวน threads หากเครื่องช้า

### การปรับแต่งในโค้ด:
```python
# ใน termux_compatible_main.py
max_workers = min(2, len(files))  # ลดจาก 4 เป็น 2
chunk_size = 4 * 1024 * 1024     # ลดจาก 8MB เป็น 4MB
```

## 📱 ฟีเจอร์ Web Interface

- 🎨 UI ที่เหมาะกับมือถือ
- ⏱️ แสดงความคืบหน้าแบบเรียลไทม์
- 📊 แสดงสถิติการค้นหา
- 📥 ดาวน์โหลดผลลัพธ์ได้ทันที
- 🔄 รองรับการค้นหาหลายครั้ง

## 📋 ข้อมูลเทคนิค

### การปรับปรุงสำหรับ Termux:
- **Threading**: ใช้ ThreadPoolExecutor แทน multiprocessing
- **Memory Management**: ปรับขนาด chunk ให้เหมาะกับ RAM ที่จำกัด
- **Error Handling**: เพิ่มการจัดการ error และ fallback
- **Timeout**: เพิ่ม timeout เพื่อป้องกันการค้าง
- **Mobile UI**: ปรับ interface ให้เหมาะกับหน้าจอมือถือ

### ข้อจำกัดบน Termux:
- ไม่รองรับ multiprocessing แบบเต็มรูปแบบ
- RAM และ CPU จำกัด
- การเข้าถึงไฟล์อาจช้ากว่า Linux ปกติ
- บางฟังก์ชัน system call อาจไม่ทำงาน

## 🆘 การขอความช่วยเหลือ

หากยังพบปัญหา กรุณาแจ้ง:
1. ข้อความ error ที่แสดง
2. ขนาดและจำนวนไฟล์ log
3. ขั้นตอนที่ทำก่อนเกิดปัญหา
4. รุ่นของ Termux และ Android

## 📈 ผลลัพธ์ที่คาดหวัง

- ✅ ค้นหาได้เร็วขึ้น 50-100% เมื่อเทียบกับโค้ดเดิม
- ✅ ใช้ RAM น้อยลง
- ✅ เสถียรกว่าบน Termux
- ✅ UI ที่ใช้งานง่ายบนมือถือ

