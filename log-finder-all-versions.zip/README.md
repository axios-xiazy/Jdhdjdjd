# Log Account Finder - ระบบค้นหาบัญชีจากไฟล์ Log

## ภาพรวม

ระบบ Log Account Finder เป็นเว็บแอปพลิเคชันที่ปรับปรุงจากโค้ด Python เดิมให้มีประสิทธิภาพสูงขึ้นและสามารถใช้งานผ่านเว็บไซต์ได้ ระบบนี้ช่วยค้นหาบัญชีผู้ใช้จากไฟล์ log ขนาดใหญ่ด้วยความเร็วสูง

## การปรับปรุงประสิทธิภาพ

### การปรับปรุงหลัก:
1. **ปรับปรุงการจัดการ Chunk**: เพิ่มขนาด chunk เป็น 32MB เพื่อลดการโอเวอร์เฮด
2. **ลดการ decode**: ทำการ decode เฉพาะบรรทัดที่จำเป็นเท่านั้น
3. **ปรับปรุงการเขียนไฟล์**: เขียนไฟล์ผลลัพธ์ในครั้งเดียวแทนการเขียนทีละบรรทัด
4. **เพิ่มจำนวน processes**: ใช้ CPU cores × 2 สำหรับงาน I/O bound

### ประสิทธิภาพที่คาดหวัง:
- ความเร็วในการประมวลผลเพิ่มขึ้น 2-3 เท่า
- การใช้หน่วยความจำที่มีประสิทธิภาพมากขึ้น
- การจัดการไฟล์ขนาดใหญ่ได้ดีขึ้น

## โครงสร้างโปรเจค

```
log-finder-backend/          # Flask Backend
├── src/
│   ├── main.py             # Entry point
│   ├── log_processor.py    # โค้ดประมวลผล log ที่ปรับปรุงแล้ว
│   ├── routes/
│   │   └── log_finder.py   # API endpoints
│   └── static/             # Frontend files (built React app)
├── log/                    # โฟลเดอร์สำหรับไฟล์ log input
├── result/                 # โฟลเดอร์สำหรับไฟล์ผลลัพธ์
└── requirements.txt

log-finder-frontend/         # React Frontend (source)
├── src/
│   ├── App.jsx            # หน้าหลักของแอปพลิเคชัน
│   └── components/        # UI components
└── dist/                  # Built files (copied to backend/static)
```

## การติดตั้งและใช้งาน

### 1. ติดตั้ง Dependencies

```bash
cd log-finder-backend
source venv/bin/activate
pip install -r requirements.txt
```

### 2. เตรียมไฟล์ Log

วางไฟล์ log ที่ต้องการค้นหาในโฟลเดอร์ `log/` โดยไฟล์ต้องมีรูปแบบ:
```
https://example.com:user@domain.com:password
http://site.com:admin@gmail.com:secret
```

### 3. เริ่มต้นเซิร์ฟเวอร์

```bash
cd log-finder-backend
source venv/bin/activate
python src/main.py
```

เซิร์ฟเวอร์จะทำงานที่ http://localhost:5000

### 4. ใช้งานผ่านเว็บไซต์

1. เปิดเว็บไซต์ที่ http://localhost:5000
2. ใส่ชื่อโดเมนที่ต้องการค้นหา (เช่น gmail.com)
3. เลือกรูปแบบข้อมูลที่ต้องการ:
   - รูปแบบ 1: url:email:pass (แสดงข้อมูลครบถ้วน)
   - รูปแบบ 2: email:pass (แสดงเฉพาะอีเมลและรหัสผ่าน)
4. คลิก "เริ่มค้นหา"
5. รอให้การประมวลผลเสร็จสิ้น
6. ดาวน์โหลดไฟล์ผลลัพธ์

## API Endpoints

### POST /api/logs/search
เริ่มต้นการค้นหา
```json
{
  "domain": "gmail.com",
  "format_type": 1
}
```

### GET /api/logs/status/{task_id}
ตรวจสอบสถานะการค้นหา

### GET /api/logs/download/{task_id}
ดาวน์โหลดไฟล์ผลลัพธ์

## ฟีเจอร์หลัก

1. **การค้นหาแบบ Real-time**: แสดงความคืบหน้าการค้นหาแบบเรียลไทม์
2. **การประมวลผลแบบขนาน**: ใช้ multiprocessing เพื่อความเร็วสูง
3. **UI ที่ใช้งานง่าย**: ออกแบบด้วย React และ Tailwind CSS
4. **การจัดการไฟล์อัตโนมัติ**: สร้างและจัดการไฟล์ผลลัพธ์อัตโนมัติ
5. **รองรับไฟล์ขนาดใหญ่**: สามารถประมวลผลไฟล์ log ขนาดใหญ่ได้อย่างมีประสิทธิภาพ

## การแก้ไขปัญหา

### ปัญหาที่อาจพบ:
1. **ไม่พบไฟล์ log**: ตรวจสอบว่าไฟล์ log อยู่ในโฟลเดอร์ `log/` และมีนามสกุล `.txt`
2. **การค้นหาช้า**: ตรวจสอบขนาดไฟล์และจำนวน CPU cores ของระบบ
3. **ไม่สามารถดาวน์โหลดได้**: ตรวจสอบว่าการค้นหาเสร็จสิ้นแล้วและมีผลลัพธ์

### การปรับแต่งประสิทธิภาพ:
- ปรับค่า `chunk_size` ใน `log_processor.py` ตามขนาดไฟล์และ RAM ที่มี
- ปรับค่า `num_processes` ตามจำนวน CPU cores
- ใช้ SSD แทน HDD สำหรับการประมวลผลที่เร็วขึ้น

## ข้อมูลเทคนิค

- **Backend**: Flask + Python 3.11
- **Frontend**: React + Tailwind CSS + shadcn/ui
- **การประมวลผล**: Multiprocessing + Memory mapping
- **การจัดเก็บ**: File-based storage
- **API**: RESTful API with CORS support

