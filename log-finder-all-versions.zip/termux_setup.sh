#!/bin/bash

echo "🔧 Setting up Log Account Finder for Termux..."
echo "================================================"

# อัปเดต packages
echo "📦 Updating packages..."
pkg update -y
pkg upgrade -y

# ติดตั้ง Python และ dependencies ที่จำเป็น
echo "🐍 Installing Python and dependencies..."
pkg install -y python python-pip

# ติดตั้ง Python packages
echo "📚 Installing Python packages..."
pip install flask flask-cors

# สร้างโฟลเดอร์ที่จำเป็น
echo "📁 Creating necessary folders..."
mkdir -p log
mkdir -p result

# สร้างไฟล์ตัวอย่าง log
echo "📝 Creating sample log file..."
cat > log/sample.txt << 'EOF'
https://example.com:user1@gmail.com:password123
https://test.com:user2@yahoo.com:pass456
http://site.com:admin@gmail.com:secret789
other:data@hotmail.com:test123
https://demo.com:test@gmail.com:demo123
EOF

echo "✅ Setup completed!"
echo ""
echo "📋 How to use:"
echo "1. Put your .txt log files in the 'log' folder"
echo "2. Run: python termux_compatible_main.py (for command line)"
echo "3. Or run: python termux_flask_app.py (for web interface)"
echo ""
echo "🌐 For web interface, open http://localhost:5000 in your browser"
echo ""
echo "📁 Sample log file created in log/sample.txt for testing"

