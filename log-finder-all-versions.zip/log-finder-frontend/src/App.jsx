import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Search, Download, FileText, Clock, Users } from 'lucide-react'
import './App.css'

function App() {
  const [domain, setDomain] = useState('')
  const [formatType, setFormatType] = useState(1)
  const [isSearching, setIsSearching] = useState(false)
  const [taskId, setTaskId] = useState(null)
  const [status, setStatus] = useState(null)
  const [error, setError] = useState('')

  const startSearch = async () => {
    if (!domain.trim()) {
      setError('กรุณาใส่ชื่อโดเมนที่ต้องการค้นหา')
      return
    }

    setIsSearching(true)
    setError('')
    setStatus(null)

    try {
      const response = await fetch('/api/logs/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          domain: domain.trim(),
          format_type: formatType
        })
      })

      const data = await response.json()
      
      if (response.ok) {
        setTaskId(data.task_id)
      } else {
        setError(data.error || 'เกิดข้อผิดพลาดในการเริ่มค้นหา')
        setIsSearching(false)
      }
    } catch (err) {
      setError('ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้')
      setIsSearching(false)
    }
  }

  const checkStatus = async () => {
    if (!taskId) return

    try {
      const response = await fetch(`/api/logs/status/${taskId}`)
      const data = await response.json()
      
      if (response.ok) {
        setStatus(data)
        if (data.status === 'completed' || data.status === 'error') {
          setIsSearching(false)
        }
      }
    } catch (err) {
      console.error('Error checking status:', err)
    }
  }

  const downloadResult = () => {
    if (taskId && status?.status === 'completed') {
      window.open(`/api/logs/download/${taskId}`, '_blank')
    }
  }

  useEffect(() => {
    let interval
    if (isSearching && taskId) {
      interval = setInterval(checkStatus, 1000)
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isSearching, taskId])

  const getProgressPercentage = () => {
    if (!status || status.total === 0) return 0
    return Math.round((status.progress / status.total) * 100)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            🔍 Log Account Finder
          </h1>
          <p className="text-lg text-gray-600">
            ค้นหาบัญชีผู้ใช้จากไฟล์ Log ด้วยความเร็วสูง
          </p>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5" />
              ค้นหาบัญชี
            </CardTitle>
            <CardDescription>
              ใส่ชื่อโดเมนที่ต้องการค้นหาและเลือกรูปแบบข้อมูลที่ต้องการ
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                ชื่อโดเมน
              </label>
              <Input
                type="text"
                placeholder="เช่น gmail.com, yahoo.com"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                disabled={isSearching}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                รูปแบบข้อมูลที่ต้องการ
              </label>
              <div className="flex gap-4">
                <label className="flex items-center">
                  <input
                    type="radio"
                    value={1}
                    checked={formatType === 1}
                    onChange={(e) => setFormatType(parseInt(e.target.value))}
                    disabled={isSearching}
                    className="mr-2"
                  />
                  url:email:pass
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    value={2}
                    checked={formatType === 2}
                    onChange={(e) => setFormatType(parseInt(e.target.value))}
                    disabled={isSearching}
                    className="mr-2"
                  />
                  email:pass
                </label>
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                {error}
              </div>
            )}

            <Button
              onClick={startSearch}
              disabled={isSearching}
              className="w-full"
              size="lg"
            >
              {isSearching ? 'กำลังค้นหา...' : 'เริ่มค้นหา'}
            </Button>
          </CardContent>
        </Card>

        {status && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                สถานะการค้นหา
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">สถานะ:</span>
                <Badge variant={
                  status.status === 'completed' ? 'default' :
                  status.status === 'error' ? 'destructive' : 'secondary'
                }>
                  {status.status === 'processing' ? 'กำลังประมวลผล' :
                   status.status === 'completed' ? 'เสร็จสิ้น' :
                   status.status === 'error' ? 'เกิดข้อผิดพลาด' : status.status}
                </Badge>
              </div>

              {status.status === 'processing' && (
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>ความคืบหน้า</span>
                    <span>{getProgressPercentage()}%</span>
                  </div>
                  <Progress value={getProgressPercentage()} className="w-full" />
                  <p className="text-sm text-gray-600 mt-2">{status.message}</p>
                </div>
              )}

              {status.status === 'completed' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-500" />
                      <span className="text-sm">
                        <strong>{status.count?.toLocaleString()}</strong> บัญชี
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-green-500" />
                      <span className="text-sm">
                        <strong>{status.duration?.toFixed(2)}</strong> วินาที
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-purple-500" />
                      <span className="text-sm">
                        ไฟล์ผลลัพธ์พร้อม
                      </span>
                    </div>
                  </div>
                  
                  <Button
                    onClick={downloadResult}
                    className="w-full"
                    size="lg"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    ดาวน์โหลดผลลัพธ์
                  </Button>
                </div>
              )}

              {status.status === 'error' && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                  {status.message}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export default App
