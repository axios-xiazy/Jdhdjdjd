from flask import Flask, request, jsonify, send_file, render_template_string
from flask_cors import CORS
import os
import threading
import time
import json
from termux_compatible_main import find_accounts_termux

app = Flask(__name__)
CORS(app)

# Global variables to track processing status
processing_status = {}

# HTML Template สำหรับ Termux
HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Account Finder - Termux</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        
        .header p {
            opacity: 0.9;
            font-size: 14px;
        }
        
        .form-container {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        input[type="text"]:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .radio-group {
            display: flex;
            gap: 20px;
            margin-top: 10px;
        }
        
        .radio-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        
        .btn:hover {
            transform: translateY(-2px);
        }
        
        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .status-container {
            margin-top: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            display: none;
        }
        
        .status-container.show {
            display: block;
        }
        
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #e1e5e9;
            border-radius: 4px;
            overflow: hidden;
            margin: 15px 0;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            width: 0%;
            transition: width 0.3s;
        }
        
        .result-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin: 15px 0;
        }
        
        .info-item {
            text-align: center;
            padding: 10px;
            background: white;
            border-radius: 6px;
        }
        
        .info-value {
            font-size: 18px;
            font-weight: 600;
            color: #667eea;
        }
        
        .info-label {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        
        .download-btn {
            background: #28a745;
            margin-top: 15px;
        }
        
        .error {
            color: #dc3545;
            background: #f8d7da;
            padding: 10px;
            border-radius: 6px;
            margin-top: 15px;
        }
        
        .success {
            color: #155724;
            background: #d4edda;
            padding: 10px;
            border-radius: 6px;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 Log Account Finder</h1>
            <p>Termux Compatible Version</p>
        </div>
        
        <div class="form-container">
            <form id="searchForm">
                <div class="form-group">
                    <label for="domain">ชื่อโดเมน:</label>
                    <input type="text" id="domain" placeholder="เช่น gmail.com, yahoo.com" required>
                </div>
                
                <div class="form-group">
                    <label>รูปแบบข้อมูลที่ต้องการ:</label>
                    <div class="radio-group">
                        <div class="radio-item">
                            <input type="radio" id="format1" name="format" value="1" checked>
                            <label for="format1">url:email:pass</label>
                        </div>
                        <div class="radio-item">
                            <input type="radio" id="format2" name="format" value="2">
                            <label for="format2">email:pass</label>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn" id="searchBtn">เริ่มค้นหา</button>
            </form>
            
            <div id="statusContainer" class="status-container">
                <div id="statusMessage">กำลังเริ่มต้นการค้นหา...</div>
                <div class="progress-bar">
                    <div id="progressFill" class="progress-fill"></div>
                </div>
                <div id="progressText">0%</div>
                <div id="resultInfo" class="result-info" style="display: none;">
                    <div class="info-item">
                        <div id="countValue" class="info-value">0</div>
                        <div class="info-label">บัญชีที่พบ</div>
                    </div>
                    <div class="info-item">
                        <div id="timeValue" class="info-value">0</div>
                        <div class="info-label">วินาที</div>
                    </div>
                </div>
                <button id="downloadBtn" class="btn download-btn" style="display: none;">ดาวน์โหลดผลลัพธ์</button>
            </div>
        </div>
    </div>

    <script>
        let currentTaskId = null;
        let statusInterval = null;

        document.getElementById('searchForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const domain = document.getElementById('domain').value.trim();
            const formatType = parseInt(document.querySelector('input[name="format"]:checked').value);
            
            if (!domain) {
                alert('กรุณาใส่ชื่อโดเมน');
                return;
            }
            
            // Reset UI
            document.getElementById('searchBtn').disabled = true;
            document.getElementById('searchBtn').textContent = 'กำลังค้นหา...';
            document.getElementById('statusContainer').classList.add('show');
            document.getElementById('downloadBtn').style.display = 'none';
            document.getElementById('resultInfo').style.display = 'none';
            
            try {
                const response = await fetch('/api/search', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        domain: domain,
                        format_type: formatType
                    })
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    currentTaskId = data.task_id;
                    startStatusCheck();
                } else {
                    showError(data.error || 'เกิดข้อผิดพลาดในการเริ่มค้นหา');
                }
            } catch (error) {
                showError('ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้');
            }
        });
        
        function startStatusCheck() {
            statusInterval = setInterval(checkStatus, 1000);
        }
        
        async function checkStatus() {
            if (!currentTaskId) return;
            
            try {
                const response = await fetch(`/api/status/${currentTaskId}`);
                const data = await response.json();
                
                if (response.ok) {
                    updateStatus(data);
                    
                    if (data.status === 'completed' || data.status === 'error') {
                        clearInterval(statusInterval);
                        document.getElementById('searchBtn').disabled = false;
                        document.getElementById('searchBtn').textContent = 'เริ่มค้นหา';
                    }
                }
            } catch (error) {
                console.error('Error checking status:', error);
            }
        }
        
        function updateStatus(status) {
            const statusMessage = document.getElementById('statusMessage');
            const progressFill = document.getElementById('progressFill');
            const progressText = document.getElementById('progressText');
            const resultInfo = document.getElementById('resultInfo');
            const downloadBtn = document.getElementById('downloadBtn');
            
            statusMessage.textContent = status.message || 'กำลังประมวลผล...';
            
            if (status.total > 0) {
                const percentage = Math.round((status.progress / status.total) * 100);
                progressFill.style.width = percentage + '%';
                progressText.textContent = percentage + '%';
            }
            
            if (status.status === 'completed') {
                document.getElementById('countValue').textContent = status.count?.toLocaleString() || '0';
                document.getElementById('timeValue').textContent = status.duration?.toFixed(2) || '0';
                resultInfo.style.display = 'grid';
                downloadBtn.style.display = 'block';
                
                downloadBtn.onclick = function() {
                    window.open(`/api/download/${currentTaskId}`, '_blank');
                };
            } else if (status.status === 'error') {
                showError(status.message);
            }
        }
        
        function showError(message) {
            const statusContainer = document.getElementById('statusContainer');
            statusContainer.innerHTML = `<div class="error">${message}</div>`;
            document.getElementById('searchBtn').disabled = false;
            document.getElementById('searchBtn').textContent = 'เริ่มค้นหา';
        }
    </script>
</body>
</html>
'''

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/search', methods=['POST'])
def search_logs():
    try:
        data = request.get_json()
        domain = data.get('domain', '').strip()
        format_type = data.get('format_type', 1)
        
        if not domain:
            return jsonify({'error': 'Domain is required'}), 400
        
        if format_type not in [1, 2]:
            return jsonify({'error': 'Format type must be 1 or 2'}), 400
        
        # Generate a unique task ID
        task_id = f"{domain}_{int(time.time())}"
        
        # Initialize processing status
        processing_status[task_id] = {
            'status': 'processing',
            'progress': 0,
            'total': 0,
            'message': 'Starting search...',
            'count': 0,
            'duration': 0,
            'output_file': None
        }
        
        def progress_callback(processed, total):
            processing_status[task_id]['progress'] = processed
            processing_status[task_id]['total'] = total
            processing_status[task_id]['message'] = f'Processing {processed}/{total} chunks...'
        
        def process_in_background():
            try:
                message, count, duration, output_file = find_accounts_termux(
                    domain, format_type, 
                    folder_path='log', 
                    output_dir='result',
                    progress_callback=progress_callback
                )
                
                processing_status[task_id].update({
                    'status': 'completed',
                    'message': message,
                    'count': count,
                    'duration': duration,
                    'output_file': output_file
                })
            except Exception as e:
                processing_status[task_id].update({
                    'status': 'error',
                    'message': f'Error: {str(e)}'
                })
        
        # Start background processing
        thread = threading.Thread(target=process_in_background)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'task_id': task_id,
            'message': 'Search started successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/status/<task_id>', methods=['GET'])
def get_status(task_id):
    if task_id not in processing_status:
        return jsonify({'error': 'Task not found'}), 404
    
    return jsonify(processing_status[task_id])

@app.route('/api/download/<task_id>', methods=['GET'])
def download_result(task_id):
    if task_id not in processing_status:
        return jsonify({'error': 'Task not found'}), 404
    
    status = processing_status[task_id]
    if status['status'] != 'completed' or not status['output_file']:
        return jsonify({'error': 'File not ready'}), 400
    
    output_file = os.path.abspath(status['output_file'])
    if not os.path.exists(output_file):
        return jsonify({'error': 'File not found'}), 404
    
    return send_file(
        output_file,
        as_attachment=True,
        download_name=os.path.basename(output_file)
    )

if __name__ == '__main__':
    # สร้างโฟลเดอร์ที่จำเป็น
    os.makedirs('log', exist_ok=True)
    os.makedirs('result', exist_ok=True)
    
    print("=" * 50)
    print("🔍 Log Account Finder - Termux Web Version")
    print("=" * 50)
    print("📁 Make sure to put your .txt files in the 'log' folder")
    print("🌐 Starting web server...")
    print("📱 Open http://localhost:5000 in your browser")
    print("=" * 50)
    
    app.run(host='0.0.0.0', port=5000, debug=False)

