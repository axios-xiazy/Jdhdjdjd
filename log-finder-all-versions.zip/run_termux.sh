#!/bin/bash

echo "🔍 Log Account Finder - Termux Version"
echo "======================================"

# ตรวจสอบว่ามี Python หรือไม่
if ! command -v python &> /dev/null; then
    echo "❌ Python not found! Please install Python first:"
    echo "   pkg install python"
    exit 1
fi

# ตรวจสอบ dependencies
echo "📦 Checking dependencies..."
python -c "import flask, flask_cors" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "⚠️ Missing dependencies. Installing..."
    pip install -r requirements_termux.txt
fi

# สร้างโฟลเดอร์ที่จำเป็น
mkdir -p log result

# ตรวจสอบไฟล์ log
if [ ! "$(ls -A log/*.txt 2>/dev/null)" ]; then
    echo "📝 No log files found. Creating sample file..."
    cat > log/sample.txt << 'EOF'
https://example.com:user1@gmail.com:password123
https://test.com:user2@yahoo.com:pass456
http://site.com:admin@gmail.com:secret789
other:data@hotmail.com:test123
https://demo.com:test@gmail.com:demo123
EOF
    echo "✅ Sample file created: log/sample.txt"
fi

echo ""
echo "🚀 Choose running mode:"
echo "1. Command Line Interface"
echo "2. Web Interface (Recommended)"
echo ""
read -p "Enter your choice (1 or 2): " choice

case $choice in
    1)
        echo "🖥️ Starting Command Line Interface..."
        python termux_compatible_main.py
        ;;
    2)
        echo "🌐 Starting Web Interface..."
        echo "📱 Open http://localhost:5000 in your browser"
        echo "🛑 Press Ctrl+C to stop the server"
        echo ""
        python termux_flask_app.py
        ;;
    *)
        echo "❌ Invalid choice. Please run the script again."
        exit 1
        ;;
esac

