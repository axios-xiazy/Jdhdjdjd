from flask import Blueprint, request, jsonify, send_file
from flask_cors import cross_origin
import os
import threading
import time
from src.log_processor import find_accounts

log_finder_bp = Blueprint('log_finder', __name__)

# Global variables to track processing status
processing_status = {}

@log_finder_bp.route('/search', methods=['POST'])
@cross_origin()
def search_logs():
    try:
        data = request.get_json()
        domain = data.get('domain', '').strip()
        format_type = data.get('format_type', 1)
        
        if not domain:
            return jsonify({'error': 'Domain is required'}), 400
        
        if format_type not in [1, 2]:
            return jsonify({'error': 'Format type must be 1 or 2'}), 400
        
        # Generate a unique task ID
        task_id = f"{domain}_{int(time.time())}"
        
        # Initialize processing status
        processing_status[task_id] = {
            'status': 'processing',
            'progress': 0,
            'total': 0,
            'message': 'Starting search...',
            'count': 0,
            'duration': 0,
            'output_file': None
        }
        
        def progress_callback(processed, total):
            processing_status[task_id]['progress'] = processed
            processing_status[task_id]['total'] = total
            processing_status[task_id]['message'] = f'Processing {processed}/{total} chunks...'
        
        def process_in_background():
            try:
                message, count, duration, output_file = find_accounts(
                    domain, format_type, 
                    folder_path='log', 
                    output_dir='result',
                    progress_callback=progress_callback
                )
                
                processing_status[task_id].update({
                    'status': 'completed',
                    'message': message,
                    'count': count,
                    'duration': duration,
                    'output_file': output_file
                })
            except Exception as e:
                processing_status[task_id].update({
                    'status': 'error',
                    'message': f'Error: {str(e)}'
                })
        
        # Start background processing
        thread = threading.Thread(target=process_in_background)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'task_id': task_id,
            'message': 'Search started successfully'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@log_finder_bp.route('/status/<task_id>', methods=['GET'])
@cross_origin()
def get_status(task_id):
    if task_id not in processing_status:
        return jsonify({'error': 'Task not found'}), 404
    
    return jsonify(processing_status[task_id])

@log_finder_bp.route('/download/<task_id>', methods=['GET'])
@cross_origin()
def download_result(task_id):
    if task_id not in processing_status:
        return jsonify({'error': 'Task not found'}), 404
    
    status = processing_status[task_id]
    if status['status'] != 'completed' or not status['output_file']:
        return jsonify({'error': 'File not ready'}), 400
    
    # Use absolute path
    output_file = os.path.abspath(status['output_file'])
    if not os.path.exists(output_file):
        return jsonify({'error': 'File not found'}), 404
    
    return send_file(
        output_file,
        as_attachment=True,
        download_name=os.path.basename(output_file)
    )

