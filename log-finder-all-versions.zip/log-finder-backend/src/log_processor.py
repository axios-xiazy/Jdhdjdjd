import os
import glob
import mmap
from multiprocessing import Pool, cpu_count
import time

def process_chunk(args):
    file_path, domain_bytes, start, end, format_type = args
    lines = []
    
    try:
        with open(file_path, 'rb') as f:
            mm = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
            
            # Adjust start to the beginning of a line
            if start > 0:
                mm.seek(start - 1)
                if mm.read(1) != b'\n':
                    prev_newline = mm.rfind(b'\n', 0, start)
                    if prev_newline != -1:
                        start = prev_newline + 1
            
            # Adjust end to the end of a line
            mm.seek(end)
            next_newline = mm.find(b'\n', end)
            end = next_newline + 1 if next_newline != -1 else mm.size()
            
            chunk = mm[start:end]
            pos = 0
            while True:
                found = chunk.find(domain_bytes, pos)
                if found == -1:
                    break
                
                line_start = chunk.rfind(b'\n', 0, found) + 1
                line_end = chunk.find(b'\n', found)
                line_end = line_end if line_end != -1 else len(chunk)
                
                # Decode only the relevant line
                line_bytes = chunk[line_start:line_end]
                line = line_bytes.decode('utf-8', errors='ignore').strip()
                
                # Format data based on user choice
                parts = line.split(':')
                if len(parts) >= 3:
                    if format_type == 1:
                        formatted_line = line
                    else:
                        if 'http' in parts[0] or 'https' in parts[0]:
                            formatted_line = ':'.join(parts[2:])
                        else:
                            formatted_line = ':'.join(parts[1:])
                    lines.append(formatted_line)
                pos = line_end + 1
            mm.close()
    except Exception:
        pass
    return lines

def process_files_parallel(files, domain, format_type, progress_callback=None):
    num_processes = cpu_count() * 2  # Use more processes than CPU cores for I/O bound tasks
    chunk_size = 32 * 1024 * 1024  # 32MB chunks
    domain_bytes = domain.encode('utf-8')
    
    chunks = []
    for file_path in files:
        try:
            file_size = os.path.getsize(file_path)
            if file_size == 0:
                continue
            for start in range(0, file_size, chunk_size):
                end = min(start + chunk_size, file_size)
                chunks.append((file_path, domain_bytes, start, end, format_type))
        except Exception:
            continue

    unique_lines = set()
    processed_chunks = 0
    
    with Pool(processes=num_processes) as pool:
        for result in pool.imap_unordered(process_chunk, chunks):
            unique_lines.update(result)
            processed_chunks += 1
            if progress_callback:
                progress_callback(processed_chunks, len(chunks))
    
    return unique_lines

def find_accounts(domain, format_type, folder_path='log', output_dir='result', progress_callback=None):
    """
    Find accounts matching the given domain
    Returns: (message, count, duration, output_file_path)
    """
    OUTPUT_FILE = os.path.join(output_dir, f'Log Account By.zxvxzv [ {domain} ].txt')

    try:
        os.makedirs(output_dir, exist_ok=True)

        files = glob.glob(os.path.join(folder_path, '*.txt'))
        if not files:
            return "No files found!", 0, 0, None

        start_time = time.time()
        unique_lines = process_files_parallel(files, domain, format_type, progress_callback)

        if unique_lines:
            # Write all lines at once for better performance
            with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
                f.write('\n'.join(unique_lines))
            
            end_time = time.time()
            duration = end_time - start_time
            
            return f"Done! Found {len(unique_lines):,} unique lines in {duration:.2f}s", len(unique_lines), duration, OUTPUT_FILE
        else:
            return "No matching data found!", 0, 0, None

    except Exception as e:
        return f"Error: {e}", 0, 0, None

