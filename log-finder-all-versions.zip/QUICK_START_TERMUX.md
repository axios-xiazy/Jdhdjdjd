# 🚀 Quick Start Guide - Termux

## การติดตั้งและใช้งานแบบรวดเร็ว

### 📱 ขั้นตอนที่ 1: ติดตั้ง
```bash
# ติดตั้ง Python (ถ้ายังไม่มี)
pkg install python python-pip

# ติดตั้ง dependencies
pip install flask flask-cors
```

### 📁 ขั้นตอนที่ 2: เตรียมไฟล์
1. วางไฟล์ .txt ที่มีข้อมูล log ในโฟลเดอร์ `log/`
2. หรือใช้ไฟล์ตัวอย่างที่สร้างให้อัตโนมัติ

### 🎯 ขั้นตอนที่ 3: รันโปรแกรม

#### วิธีง่ายที่สุด:
```bash
bash run_termux.sh
```

#### หรือรันแบบ Web Interface:
```bash
python termux_flask_app.py
```
เปิด http://localhost:5000

#### หรือรันแบบ Command Line:
```bash
python termux_compatible_main.py
```

## 🔧 แก้ไขปัญหาเร่งด่วน

### ปัญหา: ไม่มีไฟล์ log
```bash
mkdir -p log
echo "https://example.com:user@gmail.com:pass123" > log/test.txt
```

### ปัญหา: Import error
```bash
pip install flask flask-cors
```

### ปัญหา: Permission denied
```bash
chmod +x *.sh
chmod +x *.py
```

### ปัญหา: Port ถูกใช้งาน
```bash
pkill -f python
```

## ✅ การทดสอบ
ใช้โดเมน `gmail.com` กับไฟล์ตัวอย่างเพื่อทดสอบการทำงาน

## 📞 ต้องการความช่วยเหลือ?
อ่านไฟล์ `TERMUX_README.md` สำหรับรายละเอียดเพิ่มเติม

